#include "Task_Handles.h"

TaskHandle_t TaskHandle_pirSensor;
TaskHandle_t TaskHandle_DispenserSensor;
TaskHandle_t TaskHandle_FoodSensor;
TaskHandle_t TaskHandle_WaterSensor;

TaskHandle_t TaskHandle_StateLED;
TaskHandle_t TaskHandle_NotificationLED;
TaskHandle_t TaskHandle_SolenoidValve;
TaskHandle_t TaskHandle_StepperMotor;